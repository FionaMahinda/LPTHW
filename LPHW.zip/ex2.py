# A comment, this is so youcan read your program later.
# Anything after the # is ignored by pyhton

print("i could have code like this.") # and the comment after is ignored

# You can also use a comment to "disable" or comment out code:
# print("This won't run")

print("this will run")
