# number of cars available
Cars = 100
#the amount of space
space_in_a_Car = 4.0
# the number of drivers available
drivers = 30
#the total amount of passengers that need to be transported
passengers = 90
#number of cars that have no drivers
Cars_not_driven = Cars - drivers
#number of cars with drivers
Cars_driven = drivers
# the total amount of passengers that can be accomodated in each car
Carpool_capacity = Cars_driven * space_in_a_Car
#the average amount of passengers in each driven car
average_passengers_per_Car = passengers / Cars_driven


print("there are", Cars, "Cars available.")
print("Thers are only", drivers, "drivers available.")
print("There will be", Cars_not_driven, "empty Cars today.")
print("We can transport", Carpool_capacity, "to Carpool today.")
print("We have", passengers, "to Carpool today.")
print("We need to put about", average_passengers_per_Car, "in each Car.")


